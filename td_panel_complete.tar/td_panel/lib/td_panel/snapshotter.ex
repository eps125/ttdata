defmodule TdPanel.Snapshotter do
end
