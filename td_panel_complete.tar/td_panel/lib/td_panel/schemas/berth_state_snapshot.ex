defmodule TdPanel.Schemas.BerthStateSnapshot do
end
