console.log('Panel placeholder');
