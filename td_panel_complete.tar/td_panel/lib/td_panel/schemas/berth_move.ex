defmodule TdPanel.Schemas.BerthMove do
end
