defmodule TdPanel.Schemas.BerthState do
end
