defmodule TdPanel.ApiRouter do
end
